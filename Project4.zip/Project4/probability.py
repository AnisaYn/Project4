from matplotlib.pyplot import *

f = open('E_variance_T1_Ord.txt')
x0 = []
M_abs0 = []
E0 = []
#i = 0
for line in f.readlines()[1:-1]:
    
    temp = line.split("      ")
    print temp
    x0.append(float(temp[2]))
    #M_abs0.append(float(temp[3]))
    #E0.append(float(temp[4]))

x0 = np.array(x0)
ni = 20.*20.
x0 = x0/ni
hist(x0, bins="auto")

show()

