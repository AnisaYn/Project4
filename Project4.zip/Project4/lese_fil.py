import glob, os

def headere(fil):
	list_av_linjer_med_tall = []
	with open(fil,'r') as infile:
		ant_linjer_med_tekst,komma = 0,False
		for line in infile:
			words = line.split()
			words_komma = line.split(",")
			try:
				float(words[0])
				komma = False
				ferdig = True
			except:
				ferdig = False
			try: 
				float(words_komma[0])
				komma = True
				ferdig = True
			except:
				ferdig = False

			if ferdig:
				#list_av_linjer_med_tall.append(ant_linjer_med_tekst)
				break
			ant_linjer_med_tekst += 1
	return ant_linjer_med_tekst,len(line),komma
	
def filer_i_mappe(mappe)
	filer = []
	for file in glob.glob('%s/*.txt'%(mappe)):			# edit: tok bort maaletype
		filer.append(file)
	return filer