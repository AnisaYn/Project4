from numpy import *

L = [40,60,100,140]

#read from plots:
T_C_cv = [2.32, 2.29, 2.28, 2.27] #C_v
#T_C_chi = [2.34, 2.31, 2.3, 2.3] #chi

x_1 = zeros(len(T_C_cv)-1)
#x_2 = zeros(len(T_C_chi)-1)

for i in range(len(T_C_cv)-1):
	x_1[i] = (T_C_cv[i]*L[i] - T_C_cv[i+1]*L[i+1])/(L[i] - L[i+1])
	#x_2[i] = (T_C_chi[i]*L[i] - T_C_chi[i+1]*L[i+1])/(L[i] - L[i+1])

print "Numerical T_c = ", (mean(x_1) + mean(x_2))/2

theoretical_value = 2.269

print "Theoretical T_c = ", theoretical_value

print "Estimated error = ", abs((mean(x_1) + mean(x_2))/2 - theoretical_value)