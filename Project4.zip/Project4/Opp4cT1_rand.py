from matplotlib.pyplot import*

f = open('results_rand_T1.txt')
MC_cyles = []
M_abs0 = []
E0 = []
Accepted_Cycles = []

i = 0
for line in f.readlines():
    
    temp = line.split("     ")
    MC_cyles.append(float(temp[2]))
    M_abs0.append(float(temp[4]))
    E0.append(float(temp[3]))
    Accepted_Cycles.append(float(temp[6]))
    
    print temp
    i = i+1

X = 20.
MC_cyles = np.array(MC_cyles)
M_abs0 = np.array(M_abs0)/X**2
E0 = np.array(E0)/X**2
f.close()
print MC_cyles
print M_abs0
figure(1)
subplot(3,1,1)
plot(MC_cyles, M_abs0,"-b",linewidth=1.5)
title('Random configuration; when T=1.0', fontsize=16)
ylabel('$<|\mathcal{M}|>$',fontsize=14)


subplot(3,1,2)
plot(MC_cyles,E0, "-r",linewidth=1.5)
ylabel('$<E>/J$',fontsize=14)



subplot(3,1,3)
plot(MC_cyles, Accepted_Cycles, "-g",linewidth=1.5)
ylabel('Accepted Cycle per spin',fontsize=14)
xlabel('$t[kT/J]$', fontsize=16)
show()
