from matplotlib.pyplot import*

f = open('E_variance_T1_Ord.txt')
MC_cyles = []
E_variance = []
#M_abs0 = []
#E0 = []
#Accepted_Cycles = []

i = 0
for line in f.readlines():
    
    temp = line.split("     ")
    MC_cyles.append(float(temp[2]))
    E_variance.append(float(temp[3]))
    #M_abs0.append(float(temp[4]))
    #E0.append(float(temp[3]))
    #Accepted_Cycles.append(float(temp[6]))
    
    print temp
    i = i+1

X = 20.
MC_cyles = np.array(MC_cyles)
E_variance = np.array(E_variance)
#M_abs0 = np.array(M_abs0)/X**2
#E0 = np.array(E0)/X**2

f.close()
print MC_cyles
print E_variance
figure(1)

plot(MC_cyles, E_variance,"-b",linewidth=1.5)
title('Orderd configuration; when T=1.0', fontsize=16)
xlabel('E_variance')
ylabel('Monte Carlo cycles',fontsize=14)

show()
