import numpy as np
# L values
L = np.array([40,60,100,140])		
# corresponding T_c(L) values		
T_C = np.array([2.31,2.32,2.27,2.27])	

x = np.zeros(6)

x[0] = (T_C[3]-T_C[2])/(L[3]-L[2])
x[1] = (T_C[3]-T_C[1])/(L[3]-L[1])
x[2] = (T_C[3]-T_C[0])/(L[3]-L[0])
x[3] = (T_C[2]-T_C[1])/(L[2]-L[1])
x[4] = (T_C[2]-T_C[0])/(L[2]-L[0])
x[5] = (T_C[1]-T_C[0])/(L[1]-L[0])

Theoretical = 2.269

print 'Different approximations of x: '
print x

x = sum(x)/6

print 'Mean value of x: ', x
print 'Finite size scaling approximation of T_c: ', T_C[3]-x*L[3]**-1
print 'Relative error: ', abs(Theoretical-(T_C[3]-x*L[3]**-1))/Theoretical